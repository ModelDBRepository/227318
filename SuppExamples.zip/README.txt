This zipfile contains the following files:
README.txt: this file
Fig2.py:		Script for generating Figure 2.
abstrModelEqns9.py:	Script defining abstract models for Figure 2

Fig5.py			Script for generating panels BCEF of Figure 5

Fig6_generate_data.py	Script for generating data files for Figure 6
Fig6.py			Script for making panels B-J of Figure 6.

NN_mapk14.g		GENESIS chemical model definition file for Figure 6
proto21.py		Channel prototypes for Figure 6
VHC-neuron.CNG.swc	Morphology file for Figure 6

=============================================================================

To generate the figures:

Figure 2:	(takes about 10 seconds)
python Fig2.py


Figure 5:	(takes about 30 seconds)
python Fig5.py


Figure 6:	(takes about 6 hours for each generation run, 
		and 5 seconds for the final figure)
python Fig6_generate_data.py --fnumber 0 --sequence 1234

python Fig6_generate_data.py --fnumber 2 --sequence 40312

python Fig6.py	(Note that I have explicitly embedded the results from a big
		parallel run for the tuning matrices into this file.)
